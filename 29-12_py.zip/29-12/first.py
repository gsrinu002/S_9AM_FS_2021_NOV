print('hello python')

print('welcome to python world' )
