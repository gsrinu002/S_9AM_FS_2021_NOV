name='sreenivas g'
print(name)

